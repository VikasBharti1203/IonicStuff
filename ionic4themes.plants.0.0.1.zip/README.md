# foodapp

Freebie Plants App

Install:
npm i

Serve:
ionic serve

Do you need a full app like this? Contact us! :)

More info at https://ionic4themes.com